﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace Homework6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pattern = "^[0-9]{4}$";
            string text = Badj.Text;
            if (!Regex.IsMatch(text, pattern))

            {
                Badj.Text = "";
                MessageBox.Show("Въведи правилен бадж!");

            }
            else
            {
                using (StreamReader reader = new StreamReader("names.txt"))
                {
                    bool error = false;
                    string line;
                    string[] masiv;

                    while ((line = reader.ReadLine()) != null)
                    {                      
                            masiv = line.Split('-').ToArray();
                      
                        if (text == masiv[0])
                        {
                            Resault.Text = (masiv[1] + " " + "тел:" + " " + masiv[2]);
                            error = false;
                            return;
                        }
                        else
                        {
                            
                            error = true;                            
                        }
                                    
                    }
                    if  (error == true)                       
                    {
                        Resault.Text = "";
                        MessageBox.Show("Няма такъв потребител");
                        
                    }
                    

                }
            
                
            }
           

        }

        private void Resault_TextChanged(object sender, EventArgs e)
        {

        }

        private void Badj_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
